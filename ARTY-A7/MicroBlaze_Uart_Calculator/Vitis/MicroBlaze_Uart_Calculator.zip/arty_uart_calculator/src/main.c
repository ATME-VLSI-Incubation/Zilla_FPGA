#include "stdlib.h"
#include "xparameters.h"
#include "xuartlite.h"
#include "xintc.h"
#include "xil_exception.h"
#include "xil_printf.h"

#define UARTLITE_DEVICE_ID      XPAR_UARTLITE_0_DEVICE_ID
#define INTC_DEVICE_ID          XPAR_INTC_0_DEVICE_ID
#define UARTLITE_INT_IRQ_ID     XPAR_INTC_0_UARTLITE_0_VEC_ID
#define TEST_BUFFER_SIZE        1

int Status;
int num1;
int num2;
int sum;
int diff;
int prod;
int quo;
int buf;
char operator;
int num_bytes;

char eptr;

int SetupUartLite(u16 DeviceId);
int SetupInterruptSystem(XUartLite *UartLitePtr);

void RecvHandler(void *CallBackRef, unsigned int EventData);
void resetBuffer();
void XUartLite_ResetFifos	(	XUartLite * 	InstancePtr	)	;
int uart_recieve(u16 DeviceId, int num_bytes);

XUartLite UartLite;            /* The instance of the UartLite Device */
XIntc InterruptController;     /* The instance of the Interrupt Controller */

u16 ReceiveBuffer[TEST_BUFFER_SIZE];

static volatile int TotalReceivedCount;
static volatile int TotalSentCount;


int main(void)
{

	SetupUartLite(UARTLITE_DEVICE_ID);

	xil_printf("enter the 1st number\n\r");

	uart_recieve(UARTLITE_DEVICE_ID, 2);

    num1 = strtol(ReceiveBuffer, &eptr, 10);

	xil_printf("1st num : %d\n\r",num1);

	xil_printf("enter the 2nd number\n\r");

	uart_recieve(UARTLITE_DEVICE_ID, 2);

	num2 = strtol(ReceiveBuffer, &eptr, 10);

	xil_printf("2nd num : %d\n\r",num2);

	xil_printf("enter the operator\n\r");

	uart_recieve(UARTLITE_DEVICE_ID, 1);

    xil_printf("operator : %s\n\r",ReceiveBuffer);

    switch(*ReceiveBuffer) {

    case 0x002b:
    	sum = num1 + num2;
    	xil_printf("Sum : %d\n\r",sum);
    	break;

    case 0x002d:
    	diff = num1 - num2;
    	xil_printf("Difference : %d\n\r",diff);
    	break;

    case 0x002a:
    	prod = num1 * num2;
    	xil_printf("Product : %d\n\r",prod);
    	break;

    case 0x002f:
    	quo = num1 / num2;
    	xil_printf("Quotient : %d\n\r",quo);
    	break;

    default:
    	xil_printf("Invalid Operation\n\r");
    	break;
    }

}


void resetBuffer()
{
    for(int i=0;i<TEST_BUFFER_SIZE;i++){
            ReceiveBuffer[i]=0;
        }
}

int SetupUartLite(u16 DeviceId)
{
	int Status;

	Status = XUartLite_Initialize(&UartLite, DeviceId);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = XUartLite_SelfTest(&UartLite);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = SetupInterruptSystem(&UartLite);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	XUartLite_SetRecvHandler(&UartLite, RecvHandler, &UartLite);

	XUartLite_EnableInterrupt(&UartLite);

	return XST_SUCCESS;

}


void RecvHandler(void *CallBackRef, unsigned int EventData)
{
	TotalReceivedCount = EventData;
}


int SetupInterruptSystem (XUartLite *UartLitePtr)
{

	int Status;

	Status = XIntc_Initialize(&InterruptController, INTC_DEVICE_ID);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = XIntc_Connect(&InterruptController, UARTLITE_INT_IRQ_ID,
			   (XInterruptHandler)XUartLite_InterruptHandler,
			   (void *)UartLitePtr);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = XIntc_Start(&InterruptController, XIN_REAL_MODE);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	XIntc_Enable(&InterruptController, UARTLITE_INT_IRQ_ID);

	Xil_ExceptionInit();

	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
			 (Xil_ExceptionHandler)XIntc_InterruptHandler,
			 &InterruptController);

	Xil_ExceptionEnable();

	return XST_SUCCESS;
}

int uart_recieve(u16 DeviceId, int num_bytes)
{

	 XUartLite_ResetFifos(&UartLite);
     resetBuffer();

	 TotalReceivedCount=0;

	 XUartLite_Recv(&UartLite, ReceiveBuffer, num_bytes);

	 while ((TotalReceivedCount != num_bytes) ) {
	 }

	return 0;
}
